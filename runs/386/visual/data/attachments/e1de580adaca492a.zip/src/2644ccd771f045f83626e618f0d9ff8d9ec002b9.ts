import { expect, type Locator, type Page } from "@playwright/test";

/**
 * Every navigation below stops here rather than at Playwright's default, the
 * `load` event. `load` waits for every subresource, and one image the demo
 * host leaves unanswered holds it open for as long as the caller allows: of
 * the 58 requests the home page made in the WebKit run of #117, all but one
 * settled inside 3.4 seconds, and the product photo that never responded kept
 * the navigation waiting until the budget below expired — so the landmark that
 * decides whether the page arrived was never asserted once. A landmark is the
 * proof, the photography is not, and the cases that do need the images wait
 * for them through `waitForImagesLoaded`.
 */
const DOCUMENT_READY = "domcontentloaded" as const;

interface BoundingBox {
  x: number;
  y: number;
  width: number;
  height: number;
}

export abstract class BaseAppPage {
  readonly page: Page;
  readonly header: Locator;
  readonly footer: Locator;
  readonly homeLink: Locator;
  readonly productsLink: Locator;
  readonly cartLink: Locator;
  readonly signupLoginLink: Locator;
  readonly testCasesLink: Locator;
  readonly apiTestingLink: Locator;
  readonly contactUsLink: Locator;
  readonly videoTutorialsLink: Locator;
  readonly logoutLink: Locator;
  readonly deleteAccountLink: Locator;
  readonly loggedInAs: Locator;
  readonly scrollUpButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.header = page.getByRole("banner");
    this.footer = page.getByRole("contentinfo");
    // Every nav link is scoped to the header rather than matched page-wide:
    // "Cart"'s accessible name carries a leading space from its icon markup,
    // which exact matching does not trim, and several of these names are also
    // used elsewhere on the page (the hero's own "Test Cases" button, the
    // add-to-cart modal's "View Cart" link) that an unscoped match would also
    // resolve to. Verified live.
    this.homeLink = this.header.getByRole("link", { name: "Home" });
    this.productsLink = this.header.getByRole("link", { name: "Products" });
    this.cartLink = this.header.getByRole("link", { name: "Cart" });
    this.signupLoginLink = this.header.getByRole("link", {
      name: "Signup / Login",
    });
    this.testCasesLink = this.header.getByRole("link", { name: "Test Cases" });
    this.apiTestingLink = this.header.getByRole("link", {
      name: "API Testing",
    });
    this.contactUsLink = this.header.getByRole("link", { name: "Contact us" });
    this.videoTutorialsLink = this.header.getByRole("link", {
      name: "Video Tutorials",
    });
    this.logoutLink = this.header.getByRole("link", { name: "Logout" });
    this.deleteAccountLink = this.header.getByRole("link", {
      name: "Delete Account",
    });
    this.loggedInAs = page.getByText("Logged in as");
    // No text and no role: a decorative anchor the scrollUp plugin injects.
    this.scrollUpButton = page.locator("#scrollUp");
  }

  /**
   * No consent-dismiss step here: `testFixtures.ts` blocks
   * `fundingchoicesmessages`, the host that would render that banner, as
   * third-party noise. A banner that can never load has nothing to dismiss —
   * verified against all 78 published browser-driven results, every one
   * carrying the same doomed three-second wait.
   */
  protected async goto(path: string, landmark: Locator): Promise<void> {
    // The demo host sheds load with a holding page that answers on the right
    // URL and renders none of the application, so a landmark the page always
    // carries is the only proof the application arrived. Navigating again is
    // the fix, not a longer wait: the holding page never becomes the app.
    await expect(async () => {
      await this.page.goto(path, { waitUntil: DOCUMENT_READY });
      await expect(landmark).toBeVisible({ timeout: 5_000 });
    }).toPass({ intervals: [1_000, 3_000], timeout: 20_000 });
  }

  /**
   * Resolves once every image inside the scope has finished decoding.
   *
   * Product photography streams in after load, so a region holding it keeps
   * reflowing. A screenshot assertion waits for stability, and under parallel
   * load that wait can expire mid-arrival, failing on stability rather than on
   * any visual difference. Waiting for the images fixes the cause; a longer
   * screenshot timeout only moves the deadline. A broken image settles through
   * its error event, so it cannot hang this.
   *
   * Scope defaults to the document body, for a capture that takes the whole
   * viewport rather than one element. `body` is the one place CSS is
   * unavoidable: the document body carries no role and no accessible name, and
   * keeping it here means no spec has to spell a locator out.
   */
  async waitForImagesLoaded(scope?: Locator): Promise<void> {
    await (scope ?? this.page.locator("body")).evaluate(
      async (element: HTMLElement) => {
        const images: HTMLImageElement[] = Array.from(
          element.querySelectorAll("img"),
        );
        await Promise.all(
          images.map((image) =>
            image.complete && image.naturalWidth > 0
              ? Promise.resolve()
              : new Promise((resolve) => {
                  image.addEventListener("load", resolve, { once: true });
                  image.addEventListener("error", resolve, { once: true });
                }),
          ),
        );
      },
    );
  }

  /**
   * Aligns an element to the top of the viewport.
   *
   * `scrollIntoViewIfNeeded` scrolls the minimum distance required, so where it
   * lands depends on where the page already was. A visual capture of the
   * viewport needs the same framing every run, which this guarantees.
   */
  async scrollToTop(target: Locator): Promise<void> {
    // Where the target lands depends on layout. What says the layout is final
    // is the layout itself holding still, not the document reporting itself
    // loaded: that report is withheld for good by a single photo the host
    // never answers, which is why navigation no longer waits for it either.
    await this.settledBoundingBoxes([target]);
    await target.evaluate((element: Element) =>
      element.scrollIntoView({ block: "start", behavior: "instant" }),
    );
  }

  /**
   * The smallest rectangle enclosing every given locator's own box, for a
   * `page.screenshot({ clip })` capture spanning elements with no single
   * existing container tight enough to scope to directly, such as a heading
   * and the block it titles when the two are rendered as plain siblings.
   */
  async unionBoundingBox(locators: Locator[]): Promise<BoundingBox> {
    let boxes = await this.settledBoundingBoxes(locators);
    if (!this.fitsInViewport(this.union(boxes))) {
      // A clip is read against the viewport, so a union the viewport no longer
      // holds cannot be captured at all — VR-08 subscribed, and the images
      // arriving behind it pushed the widget it had scrolled to back out of
      // sight. Bringing the locators in costs the captures that already frame
      // correctly nothing: `scrollIntoViewIfNeeded` leaves an element that is
      // already fully visible exactly where it is. Reversed, so the first
      // locator is the one the page ends up anchored on.
      for (const locator of [...locators].reverse()) {
        await locator.scrollIntoViewIfNeeded();
      }
      boxes = await this.settledBoundingBoxes(locators);
    }
    return this.union(boxes);
  }

  private union(boxes: BoundingBox[]): BoundingBox {
    const left = Math.min(...boxes.map((box) => box.x));
    const top = Math.min(...boxes.map((box) => box.y));
    const right = Math.max(...boxes.map((box) => box.x + box.width));
    const bottom = Math.max(...boxes.map((box) => box.y + box.height));
    return { x: left, y: top, width: right - left, height: bottom - top };
  }

  private fitsInViewport(box: BoundingBox): boolean {
    const viewport = this.page.viewportSize();
    if (!viewport) {
      return true;
    }
    return (
      box.x >= 0 &&
      box.y >= 0 &&
      box.x + box.width <= viewport.width &&
      box.y + box.height <= viewport.height
    );
  }

  /**
   * Every given locator's own box, read once two consecutive reads agree.
   *
   * A box is measured against the viewport, and this page keeps moving under
   * its own photography: navigation returns as soon as the document is
   * parsed, so the images that size the page arrive while a spec is already
   * working. A box read mid-reflow describes a place the element has since
   * left. Two readings that agree is the condition worth waiting for — how
   * long this host takes to send a photo is not something a number here could
   * honestly state.
   */
  private async settledBoundingBoxes(
    locators: Locator[],
  ): Promise<BoundingBox[]> {
    let previous = "";
    let settled: BoundingBox[] = [];
    await expect(async () => {
      const boxes = await Promise.all(
        locators.map((locator) => locator.boundingBox()),
      );
      // A locator can read back without a box and still paint: this site's
      // Bootstrap rows collapse to zero height around floated children, the
      // newsletter success banner's among them. Those are left out of the
      // union rather than waited on, which is what the capture has always
      // done — only the reading has to be whole.
      const resolved = boxes.filter((box) => box !== null);
      expect(resolved.length).toBeGreaterThan(0);
      const reading = JSON.stringify(resolved);
      const agrees = reading === previous;
      previous = reading;
      settled = resolved;
      expect(agrees).toBe(true);
    }).toPass();
    return settled;
  }

  /**
   * Waits until a locator's own bounding box stops changing between two
   * consecutive reads, for content whose *presence* is a poor proxy for its
   * *final size* — a Bootstrap accordion panel, for instance, keeps pushing
   * later siblings down for a moment after the panel's own text is already
   * visible, verified live: a `unionBoundingBox` taken right after that text
   * appears can still miss a sibling that has not finished being pushed into
   * place. `animations: "disabled"` does not cover this, since the sibling is
   * being repositioned by the transitioning element's layout, not animating
   * itself.
   */
  async waitForStableBoundingBox(locator: Locator): Promise<void> {
    await this.settledBoundingBoxes([locator]);
  }

  /**
   * Scrolls with the wheel rather than the API on purpose. The control is fixed
   * at a negative offset until the plugin animates it in, and it listens for a
   * real scroll: `window.scrollTo` leaves it off screen and unclickable.
   */
  async scrollDownAndReturnToTop(): Promise<void> {
    await this.page.mouse.wheel(0, 2500);
    await this.scrollUpButton.click();
  }

  async logout(): Promise<void> {
    await this.logoutLink.click();
  }

  async deleteAccount(): Promise<void> {
    await this.deleteAccountLink.click();
  }
}
