import { expect, test as base } from "@playwright/test";
import { applyAllureLabels } from "./allureLabels";
import {
  AccountInfoPage,
  CartPage,
  CheckoutPage,
  ConfirmationPage,
  HomePage,
  LoginPage,
  OrderConfirmationPage,
  PaymentPage,
  ProductDetailPage,
  ProductsPage,
} from "../pageObjects";
import { buildAccount, type TestAccount } from "../testData";
import { url } from "../url";

export interface ActiveAccount extends TestAccount {
  /** Set by a test that deletes the account itself, so teardown skips cleanup. */
  deleted: boolean;
}

/**
 * Page objects reach a test as fixtures, the shape Playwright's fixtures
 * documentation recommends: built on demand for the tests that name them, so a
 * spec declares the surfaces it touches in its signature.
 */
interface PageObjects {
  homePage: HomePage;
  productsPage: ProductsPage;
  productDetailPage: ProductDetailPage;
  loginPage: LoginPage;
  accountInfoPage: AccountInfoPage;
  confirmationPage: ConfirmationPage;
  cartPage: CartPage;
  checkoutPage: CheckoutPage;
  paymentPage: PaymentPage;
  orderConfirmationPage: OrderConfirmationPage;
}

interface Fixtures extends PageObjects {
  uniqueAccount: ActiveAccount;
}

/**
 * Ad, analytics, and consent-management traffic. None of it belongs to the
 * product under test, and all of it injects layout shifts and timing noise.
 */
const THIRD_PARTY_HOSTS =
  /(googlesyndication|doubleclick|googletagservices|googletagmanager|google-analytics|adtrafficquality|fundingchoicesmessages)\./;

/**
 * The cart's AJAX write endpoints. Both are GETs that mutate the session cart,
 * so re-issuing one is safe: it sets the same quantity or removes the same row.
 */
const CART_WRITE_ENDPOINTS =
  /automationexercise\.com\/(add_to_cart|delete_cart)\//;

export const test = base.extend<Fixtures & { allureLabels: void }>({
  /**
   * Labels every result so the dashboard can group and filter it: the two
   * suites separate, each area becomes its own branch, and a case links to the
   * plan that justifies it. Automatic, because a label applied only where
   * someone remembered is a label the report cannot rely on.
   */
  allureLabels: [
    // The empty pattern is Playwright's own signature for a fixture that
    // depends on nothing; naming a dependency here would force it to be built.
    async ({}, use, testInfo) => {
      await applyAllureLabels(testInfo);
      await use();
    },
    { auto: true },
  ],

  page: async ({ page }, use) => {
    await page.route(THIRD_PARTY_HOSTS, (route) => route.abort());

    /**
     * The demo host sporadically sheds a cart write with a 503, seen in a trace
     * as `GET /add_to_cart/1?quantity=1 -> 503` on a page where every other
     * request returned 200. The app ignores the failure silently, so the modal
     * never opens and the test times out on a state that cannot arrive.
     *
     * One retry on that request, not a loop. It changes nothing the tests
     * assert: an endpoint that is genuinely broken still fails twice.
     */
    await page.route(CART_WRITE_ENDPOINTS, async (route, request) => {
      if (request.method() !== "GET") {
        return route.fallback();
      }

      let response = await route.fetch();
      if (response.status() >= 500) {
        response = await route.fetch();
      }

      await route.fulfill({ response });
    });

    await use(page);
  },

  homePage: async ({ page }, use) => {
    await use(new HomePage(page));
  },

  productsPage: async ({ page }, use) => {
    await use(new ProductsPage(page));
  },

  productDetailPage: async ({ page }, use) => {
    await use(new ProductDetailPage(page));
  },

  loginPage: async ({ page }, use) => {
    await use(new LoginPage(page));
  },

  accountInfoPage: async ({ page }, use) => {
    await use(new AccountInfoPage(page));
  },

  confirmationPage: async ({ page }, use) => {
    await use(new ConfirmationPage(page));
  },

  cartPage: async ({ page }, use) => {
    await use(new CartPage(page));
  },

  checkoutPage: async ({ page }, use) => {
    await use(new CheckoutPage(page));
  },

  paymentPage: async ({ page }, use) => {
    await use(new PaymentPage(page));
  },

  orderConfirmationPage: async ({ page }, use) => {
    await use(new OrderConfirmationPage(page));
  },

  /**
   * Registers a throwaway account for the test and removes it afterwards.
   * Each test owns its own account, so parallel workers never contend and no
   * test inherits state from another.
   */
  uniqueAccount: async ({ page }, use) => {
    const account: ActiveAccount = { ...buildAccount(), deleted: false };

    const loginPage = new LoginPage(page);
    const accountInfoPage = new AccountInfoPage(page);
    const confirmationPage = new ConfirmationPage(page);
    const homePage = new HomePage(page);

    await loginPage.gotoLoginPage();
    await loginPage.startSignup(account.name, account.email);

    await accountInfoPage.createAccount(account);

    await confirmationPage.continueButton.waitFor({ state: "visible" });
    await confirmationPage.continue();

    await use(account);

    if (account.deleted) {
      return;
    }

    await homePage.gotoHomePage();
    const stillSignedIn = await homePage.logoutLink
      .isVisible()
      .catch(() => false);

    if (!stillSignedIn) {
      await loginPage.gotoLoginPage();
      await loginPage.login(account.email, account.password);
      // login() submits the form and returns; the session only exists once
      // that POST has been processed. Navigating straight to /delete_account
      // can overtake it and arrive anonymously, which deletes nothing and
      // fails the assertion below for the wrong reason.
      await expect(homePage.logoutLink).toBeVisible();
    }

    await page.goto(url.deleteAccount);
    // A silent teardown failure would leak accounts run after run with nothing
    // surfacing, so cleanup asserts its own outcome.
    await expect(confirmationPage.accountDeletedBanner).toBeVisible();
  },
});

export { expect } from "@playwright/test";
